const controller = require('./controller')
const routes = require('./routes')
const model = require('./model')

module.exports = {
  routes,
  controller,
  model
}
