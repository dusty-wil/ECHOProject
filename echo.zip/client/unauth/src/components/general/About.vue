<template>
    <div class="container">
        <div class="row">
            <div class="bodyWrapper">
                <h2>About</h2>
                <p>
                    This is some text this is a test 123 asdfasdasd
                    This is some text this is a test 123 asdfasdasd
                    This is some text this is a test 123 asdfasdasd
                    This is some text this is a test 123 asdfasdasd
                    This is some text this is a test 123 asdfasdasd
                    This is some text this is a test 123 asdfasdasd
                    This is some text this is a test 123 asdfasdasd
                    This is some text this is a test 123 asdfasdasd
                    This is some text this is a test 123 asdfasdasd
                </p>
            </div>
        </div>
    </div>
</template>
<script>
</script>
