export default {
  api_version: 'v1'
}
